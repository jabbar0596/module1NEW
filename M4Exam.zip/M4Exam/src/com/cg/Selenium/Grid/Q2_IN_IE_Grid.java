package com.cg.Selenium.Grid;


import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Platform;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.openqa.selenium.support.ui.Select;
import org.apache.xalan.Version;


public class Q2_IN_IE_Grid {

	static String driverpath="C:\\Users\\jabmoham\\Documents\\zip files\\VnVATParticipantsMaterial\\VNV Software\\Selenium\\";
	
	
	public static void main(String args[]) throws MalformedURLException 
	{
		System.setProperty("webdriver.chrome.driver", driverpath+"IEDriverServer.exe");
		
		DesiredCapabilities capability = DesiredCapabilities.internetExplorer();
		capability.setBrowserName("internetExplorer");
		capability.setPlatform(Platform.ANY);
		capability.setVersion(Version.getVersion());
		
		WebDriver driver=new RemoteWebDriver(new URL("http://192.160.20.104:4444/wd/hub"), capability);
		
//		try 
		{
//				  1. Launch the URL on Chrome
			      driver.navigate().to("http://demo.opencart.com/");
        		  driver.manage().window().maximize();
                  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
//				  3. Verify 'Title' of the page
		    	  String expectedTitle ="Your Store";
				  String actualTitle = driver.getTitle();
				  System.out.println("Actual   Title is : "+actualTitle);
				  System.out.println("Expected Title is : "+expectedTitle);
				  
				  if(actualTitle.contains(expectedTitle))
				  {
				      System.out.println("Title Test Case Passed");	  
				  }
				  else
				  {
					  System.out.println("Title Test Case Failed");
				  }
				  System.out.println("------------------------------\n");

				  
//				  4. Click on '0 items(s)-$0.00' button
				  driver.findElement(By.xpath("//div[@id='cart']/button")).click();
				  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				  
//		        5. Verification of Dropdown Message...
					String cartExpectedText ="Your shopping cart is empty!";
					String cartActualText = driver.findElement(By.xpath("//*[@id='cart']/ul/li/p")).getText();
					System.out.println("Drop down Message is : "+cartActualText);
					System.out.println("Expected  Message is : "+cartExpectedText);
					if(cartActualText.contains(cartExpectedText))
					  {
					      System.out.println("Cart Message Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Cart Message Test Case Failed");
					  }
					System.out.println("------------------------------\n");

//				6.Click on 'Currency' dropdown and Select 'Pound Sterling' value
					
//					driver.findElement(By.xpath("//*[@id='currency']/div/button")).click();
					driver.findElement(By.xpath("//*[@id='form-currency']/div/button")).click();
		            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		            
					driver.findElement(By.xpath("//*[@id='form-currency']/div/ul/li[2]/button")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
				
//				7.Validate the selected Currency
					String selectedCurrency = driver.findElement(By.xpath("//*[@id='form-currency']/div/button")).getText();
					System.out.println("Actual   Currency : "+selectedCurrency);
					System.out.println("Expected Currency : � Pound Streling");

					if(selectedCurrency.contains("�"))
					  {
					      System.out.println("Validate Currency Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Validate Currency Test Case Failed");
					  }
					System.out.println("------------------------------\n");

//				  8. Click on contact button '123456789'
					driver.findElement(By.xpath("//*[@id='top-links']/ul/li[1]/a/i")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					
//				  9. Verify  Heading 'contact us'
					String actualHeading = driver.findElement(By.xpath("//*[@id='content']/h1")).getText();
					String expectedHeading="Contact Us";

					System.out.println("Actual   Heading : "+actualHeading);
					System.out.println("Expected Heading : "+expectedHeading);

					if(actualHeading.contains(expectedHeading))
					  {
					      System.out.println("Heading Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Heading Test Case Failed");
					  }
					System.out.println("------------------------------\n");

//				  10. Verify the default address under 'our location' i.e. Your Store and Telephone
					String actualAddress = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[1]/address")).getText();
					String expectedAddress="Address 1";

					System.out.println("Actual   Address : "+actualAddress);
					System.out.println("Expected Address : "+expectedAddress);

					if(actualAddress.contains(expectedAddress))
					  {
					      System.out.println("Address Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Address Test Case Failed");
					  }
					System.out.println("------------------------------\n");
					
					String actualTelephone = driver.findElement(By.xpath("//*[@id='content']/div/div/div/div[2]")).getText();
					String expectedTelephone="123456789";

					System.out.println("Actual   Telephone : "+actualTelephone);
					System.out.println("Expected Telephone : "+expectedTelephone);

					if(actualTelephone.contains(expectedTelephone))
					  {
					      System.out.println("Telephone Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Telephone Test Case Failed");
					  }
					System.out.println("------------------------------\n");
								

//				  11. Enter the details in Contact Form section
//				  12.Enter name in  'Your Name' text box
					driver.findElement(By.id("input-name")).sendKeys("Jabbar");

//				  12.Enter invalid email and click on submit button
					driver.findElement(By.id("input-email")).sendKeys("igate.c.n");
					System.out.println("Entered Email Address is : "+driver.findElement(By.id("input-email")).getAttribute("value"));
					driver.findElement(By.xpath("//*[@id='content']/form/div/div/input")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					String expectedEmailError="E-Mail Address does not appear to be valid!";
					try
					{
					String actualEmailError = driver.findElement(By.xpath("//*[@id='content']/form/fieldset/div[2]/div/div")).getText();
					if(actualEmailError.contains(expectedEmailError))
					  {
					      System.out.println("Email Error Message Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Email Error Message Test Case Failed");
					  }
					}catch(Exception exp)
					{
						System.out.println("Email Address is Valid");
					}
					
					System.out.println("------------------------------\n");
					
//				  15. Enter  the valid email address
					driver.findElement(By.id("input-email")).clear();
					driver.findElement(By.id("input-email")).sendKeys("jabbar@gmail.com");
					
//				  16. Enter text in Enquiry
					driver.findElement(By.id("input-enquiry")).sendKeys("Enter text in Enquiry");
					
//				  18. click on submit button
					driver.findElement(By.xpath("//*[@id='content']/form/div/div/input")).click();
//					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);			
					driver.manage().timeouts().pageLoadTimeout(2, TimeUnit.SECONDS);
							
//				  21. Click on Continue				 
					driver.findElement(By.linkText("Continue")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);			
				

//		    	  22. Click on Brands under Extras				 
					driver.findElement(By.linkText("Brands")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);		
					
//				  23. verify the title
		    	  expectedTitle ="Find Your Favorite Brand";
				  actualTitle = driver.getTitle();
				  System.out.println("Actual   Title is : "+actualTitle);
				  System.out.println("Expected Title is : "+expectedTitle);
				  
				  if(actualTitle.contains(expectedTitle))
				  {
				      System.out.println("Title Test Case Passed");	  
				  }
				  else
				  {
					  System.out.println("Title Test Case Failed");
				  }
				  System.out.println("------------------------------\n");

//		    	  24. Click on sony and validate
					driver.findElement(By.linkText("Sony")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					
//				    Change on 'Currency' dropdown and Select 'Pound Sterling' US dOllor
					
//					driver.findElement(By.xpath("//*[@id='currency']/div/button")).click();
					driver.findElement(By.xpath("//*[@id='form-currency']/div/button")).click();
		            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		            
					driver.findElement(By.name("USD")).click();
					driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					
					String priceAndTax = driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[1]/p[2]")).getText();

					if(priceAndTax.contains("$1,202.00"))
					  {
					      System.out.println("Price Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Price Test Case Failed");
					  }
					  System.out.println("------------------------------\n");
		 
					if(priceAndTax.contains("Ex Tax: $1,000.00"))
					  {
					      System.out.println("Tax Test Case Passed");	  
					  }
					  else
					  {
						  System.out.println("Tax Test Case Failed");
					  }
					  System.out.println("------------------------------\n");
					  
//					  26. Click on 'Add to Cart' button
					  
					  driver.findElement(By.xpath("//*[@id='content']/div[2]/div/div/div[2]/div[2]/button[1]")).click();
					  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
					  
			 
					  
					  

//		          14.Verify message 'Success: You have added Sony VAIO to your shopping cart!" to your wish list!'
				 		String actualSuccessMsg = driver.findElement(By.xpath("//*[@id='product-manufacturer']/div[1]")).getText();
						String expectedSuccessMsg ="Success: You have added Sony VAIO to your shopping cart!\n�";
						  
						System.out.println("Actual   Success Message : "+actualSuccessMsg);
						System.out.println("Expected Success Message : "+expectedSuccessMsg);
				 		boolean flag = actualSuccessMsg.contains(expectedSuccessMsg);
		                if(flag)
		                {
		                	System.out.println("success message test case is passed");	
		                }
		                else
		                {
		                	System.out.println("success message test case is failed");	
		                }
				 		
//		          27. Click on '1item(s) - $ 1,1202.00' button
		              driver.findElement(By.xpath("//div[@id='cart']/button")).click();
		      		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		      		  
//		      	28. Verify the item from DropDown
		      		String itemName = driver.findElement(By.linkText("Sony VAIO")).getText();
		      		
		            if(itemName.contains("Sony VAIO"))
		            {
		            	System.out.println("Item Name test case is passed");	
		            }
		            else
		            {
		            	System.out.println("Item Name test case is failed");	
		            }
		              
		      //Close Application
		        driver.close();

		}
	//	catch(Exception exp)
//		{
//			System.out.println("Error: Program not working");
//		}

	}
}

